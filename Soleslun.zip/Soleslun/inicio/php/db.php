<?php
$conexion=mysqli_connect("localhost","root","","basesoleslun") or 
die ("Problemas de conexión X_X");
?>