<?php
    session_start();
    
    if(!isset($_SESSION['usuario'])
    ){
        header("location: iniciosesion.HTML");
        exit();
    }   
    $nombreu = $_SESSION['usuario'];
    $rolu =  $_SESSION['usuario-rol'];

      ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Horario Sena</title> 
</head>
<body>


<h1>Hola usuario <?php echo $nombreu ?> su rol es: <?php echo $rolu ?> </h1>

</body>
</html>