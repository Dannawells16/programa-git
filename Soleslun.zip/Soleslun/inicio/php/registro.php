<?php
$conexion=mysqli_connect("localhost","root","","basesoleslun") or 
die ("Problemas de conexión X_X");

$usuario = $_POST["usuario"];
$contrasena = $_POST["contrasena"];

if(!$conexion)
{ 
    echo "no se ha podido conectar con el servidor" .mysql_error();
}
else 
{
    echo "te has conectado al servidor";
}

$datab = "basesoleslun";

$db = mysqli_select_db($conexion,$datab);

if ($db)
{
    echo "no se ha podido encontrar";
}
else
{
    echo "tabla seleccionada";
}

$intruccion_SQL = mysqli_query($conexion,"SELECT usuario.nombre, rol.nombrerol, rol.idrol FROM usuario_rol INNER JOIN usuario 
ON usuario.idusuario = usuario_rol.usuario_idusuario INNER JOIN rol ON rol.idrol = usuario_rol.rol_idrol
  WHERE usuario.nombre ='$usuario' AND usuario.contrasena='$contrasena' ")
   or die(mysqli_error($conexion));

$resultado = mysqli_query($conexion,$intruccion_SQL);

$consulta = "SELECT usuario.nombre, rol.nombrerol, rol.idrol FROM usuario_rol INNER JOIN usuario 
ON usuario.idusuario = usuario_rol.usuario_idusuario INNER JOIN rol ON rol.idrol = usuario_rol.rol_idrol
  WHERE usuario.nombre ='$usuario' AND usuario.contrasena='$contrasena' ")


?>