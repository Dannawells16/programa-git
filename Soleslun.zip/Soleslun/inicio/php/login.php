<?php
  session_start();
  include('db.php'); 
  
  $usuario=$_POST['usuario'];
  $contrasena=$_POST['contrasena'];
  
  $registros = mysqli_query($conexion,"SELECT usuario.nombre, rol.nombrerol, rol.idrol FROM usuario_rol INNER JOIN usuario 
  ON usuario.idusuario = usuario_rol.usuario_idusuario INNER JOIN rol ON rol.idrol = usuario_rol.rol_idrol
    WHERE usuario.nombre ='$usuario' AND usuario.contrasena='$contrasena' ") 
  or die(mysqli_error($conexion));
  if ($reg=mysqli_fetch_array($registros)) {
  
  $comp=$reg['idrol'];
  
  if ($comp==1){
  
    $_SESSION['login']=$usuario;
    $_SESSION['usuario']=$reg['nombre'];
   
    $_SESSION['usuario-rol']=$reg['nombrerol'];

  
    $_SESSION['SESSION']=$_SESSION;
    
    $_SESSION['ID']=$comp;
  
    echo"<script>self.location='../php/indexad.php';</script>";
   
    }
    if ($comp==2){
  
        $_SESSION['login']=$usuario;
        $_SESSION['usuario']=$reg['nombre'];
       
        $_SESSION['usuario-rol']=$reg['nombrerol'];
      
        $_SESSION['SESSION']=$_SESSION;
    $_SESSION['SESSION']=$_SESSION;
  
      echo"<script>self.location='inicio/php/indexcli.php';</script>";
    
      }
    else
    {	
       echo"<script language= 'javascript' >
         alert('Datos incorrectos porfavor verifique Usuario y/o Contraseña')
         self.location='../../index.html';
         </script>";
         
   }
  }
  
  ?>